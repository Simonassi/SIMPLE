package situations.esper.model.bank;

public class MobileDevice extends Device {

}
