package situations.esper.model.bank;

public class Device extends SpatialEntity {

}
