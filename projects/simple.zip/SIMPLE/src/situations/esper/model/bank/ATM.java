package situations.esper.model.bank;

public class ATM extends Device {

}
