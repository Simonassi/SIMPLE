package situations.esper.model.bank;

public class IntangibleEntity {

}
