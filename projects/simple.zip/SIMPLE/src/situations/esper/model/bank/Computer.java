package situations.esper.model.bank;

public class Computer extends Device {

}
