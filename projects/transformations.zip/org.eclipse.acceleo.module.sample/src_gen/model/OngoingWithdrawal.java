package .model;
import .*;

public class OngoingWithdrawal extends Situation{
	
	private Monetary value;
	private Account hasWithdrawal;
	private ATM doWithdrawal;
	private String key;	

	public Monetary getValue() {
		return value;
	}

	public void setValue(Monetary value) {
		this.value = value;
	}
	
	public Account getHasWithdrawal() {
		return hasWithdrawal;
	}

	public void setHasWithdrawal(Account hasWithdrawal) {
		this.hasWithdrawal = hasWithdrawal;
	}
	
	public ATM getDoWithdrawal() {
		return doWithdrawal;
	}

	public void setDoWithdrawal(ATM doWithdrawal) {
		this.doWithdrawal = doWithdrawal;
	}
	
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	@Override
	public Situation createNewSit(EventBean event) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object doActionAtCreateDeactivationEvent() {
		// TODO Auto-generated method stub
		return null;
	}

}
