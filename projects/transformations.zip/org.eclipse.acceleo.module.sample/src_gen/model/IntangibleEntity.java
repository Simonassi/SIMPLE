package .model;

import .*;

public abstract class IntangibleEntity {
	
		

}
