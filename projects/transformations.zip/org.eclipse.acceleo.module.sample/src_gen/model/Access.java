package .model;
import .*;

public class Access extends Situation{
	
	private Account isAccessed;
	private Device isAcessing;
	private String key;	

	public Account getIsAccessed() {
		return isAccessed;
	}

	public void setIsAccessed(Account isAccessed) {
		this.isAccessed = isAccessed;
	}
	
	public Device getIsAcessing() {
		return isAcessing;
	}

	public void setIsAcessing(Device isAcessing) {
		this.isAcessing = isAcessing;
	}
	
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	@Override
	public Situation createNewSit(EventBean event) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object doActionAtCreateDeactivationEvent() {
		// TODO Auto-generated method stub
		return null;
	}

}
