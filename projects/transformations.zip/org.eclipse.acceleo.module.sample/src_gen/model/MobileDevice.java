package .model;

import .*;

public class MobileDevice extends Device {
	
	private String key;	

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}
}
