package .model;

import .*;

public abstract class SpatialEntity {
	
	private Location location;
		

	public void setLocation(Location location) {
		this.location = location;
	}

	public Location getLocation() {
		return location;
	}
	
}
