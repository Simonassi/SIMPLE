package .model;

import .*;

public class Patient {
	
	private String[] symptoms;
	private boolean requiresHospitalization;
	private String name;
	private int temperature;
	private String key;	

	public void setSymptoms(String[] symptoms) {
		this.symptoms = symptoms;
	}

	public String[] getSymptoms() {
		return symptoms;
	}
	
	public void setRequiresHospitalization(boolean requiresHospitalization) {
		this.requiresHospitalization = requiresHospitalization;
	}

	public boolean getRequiresHospitalization() {
		return requiresHospitalization;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
	
	public void setTemperature(int temperature) {
		this.temperature = temperature;
	}

	public int getTemperature() {
		return temperature;
	}
	
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}
}
