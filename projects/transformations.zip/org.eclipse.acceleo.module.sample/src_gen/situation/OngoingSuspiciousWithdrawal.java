package .situation;

import com.espertech.esper.client.EventBean;

import .model.*;
import .situation.*;
import .*;

public class OngoingSuspiciousWithdrawal extends Situation {
	
	private ATM aTM1;
	private OngoingWithdrawal ongoingWithdrawal1;
	private Account account;

	public void setATM1( ATM aTM1) {
		this.aTM1 = aTM1;
	}
	
	public ATM getATM1() {
		return aTM1;
	}
	public void setOngoingWithdrawal1( OngoingWithdrawal ongoingWithdrawal1) {
		this.ongoingWithdrawal1 = ongoingWithdrawal1;
	}
	
	public OngoingWithdrawal getOngoingWithdrawal1() {
		return ongoingWithdrawal1;
	}
	public void setAccount( Account account) {
		this.account = account;
	}
	
	public Account getAccount() {
		return account;
	}
	
	@Override
	public OngoingSuspiciousWithdrawal(){
		setSitName("OngoingSuspiciousWithdrawal");

		setEplA("select 	ongoingWithdrawal1.doWithdrawal as aTM1, ongoingWithdrawal1, ongoingWithdrawal1.hasWithdrawal as account, ongoingWithdrawal1.key as key1 	 from 	OngoingWithdrawal as ongoingWithdrawal1  where 	ongoingWithdrawal1.activated = true and ongoingWithdrawal1.value > $1000");

		setEplA("select 	OngoingSuspiciousWithdrawal, OngoingSuspiciousWithdrawal.ongoingWithdrawal1.key as key1 	 from 	OngoingSuspiciousWithdrawal.std:unique(id) as OngoingSuspiciousWithdrawal, OngoingWithdrawal.std:unique(key) as ongoingWithdrawal1  where 	OngoingSuspiciousWithdrawal.activated is true and ( (OngoingSuspiciousWithdrawal.ongoingWithdrawal1.key = ongoingWithdrawal1.key and ongoingWithdrawal1.activated is not true)  or  (OngoingSuspiciousWithdrawal.ongoingWithdrawal1.key = ongoingWithdrawal1.key and not (ongoingWithdrawal1.value > $1000)) )  ");
	}

	@Override
	public Situation createNewSit(EventBean event) {
		OngoingSuspiciousWithdrawal ongoingSuspiciousWithdrawal = new OngoingSuspiciousWithdrawal();
        
		try{
			ongoingSuspiciousWithdrawal.setATM1((ATM)event.get("aTM1"));
			ongoingSuspiciousWithdrawal.setOngoingWithdrawal1((OngoingWithdrawal)event.get("ongoingWithdrawal1"));
			ongoingSuspiciousWithdrawal.setAccount((Account)event.get("account"));
		}catch(Exception e){
    		System.out.println("OngoingSuspiciousWithdrawal: " + e);
    	}
		
		return ongoingSuspiciousWithdrawal;
	}

	@Override
	public Object doActionAtCreateDeactivationEvent() {
		OngoingSuspiciousWithdrawal ongoingSuspiciousWithdrawal = new OngoingSuspiciousWithdrawal();
        
		try{
			ongoingSuspiciousWithdrawal.setATM1(this.getATM1());
			ongoingSuspiciousWithdrawal.setOngoingWithdrawal1(this.getOngoingWithdrawal1());
			ongoingSuspiciousWithdrawal.setAccount(this.getAccount());
		}catch(Exception e){
    		System.out.println("OngoingSuspiciousWithdrawal: " + e);
    	}
		
		return ongoingSuspiciousWithdrawal;
	}

}

