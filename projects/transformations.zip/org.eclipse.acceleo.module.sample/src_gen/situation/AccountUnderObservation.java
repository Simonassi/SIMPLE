package .situation;

import com.espertech.esper.client.EventBean;

import .model.*;
import .situation.*;
import .*;

public class AccountUnderObservation extends Situation {
	
	private OngoingSuspiciousWithdrawal ongoingSuspiciousWithdrawal1;
	private Account account;

	public void setOngoingSuspiciousWithdrawal1( OngoingSuspiciousWithdrawal ongoingSuspiciousWithdrawal1) {
		this.ongoingSuspiciousWithdrawal1 = ongoingSuspiciousWithdrawal1;
	}
	
	public OngoingSuspiciousWithdrawal getOngoingSuspiciousWithdrawal1() {
		return ongoingSuspiciousWithdrawal1;
	}
	public void setAccount( Account account) {
		this.account = account;
	}
	
	public Account getAccount() {
		return account;
	}
	
	@Override
	public AccountUnderObservation(){
		setSitName("AccountUnderObservation");

		setEplA("select 	ongoingSuspiciousWithdrawal1, ongoingSuspiciousWithdrawal1.account as account 	 from 	OngoingSuspiciousWithdrawal as ongoingSuspiciousWithdrawal1  where 	ongoingSuspiciousWithdrawal1.activated = false");

		setEplA("select 	AccountUnderObservation 	 from 	pattern[  		AccountUnderObservation = AccountUnderObservation -> 		every ( 			   timer:interval( 2 s ) 			   and not OngoingSuspiciousWithdrawal (activated = false) 	          ) 		   ]   ");
	}

	@Override
	public Situation createNewSit(EventBean event) {
		AccountUnderObservation accountUnderObservation = new AccountUnderObservation();
        
		try{
			accountUnderObservation.setOngoingSuspiciousWithdrawal1((OngoingSuspiciousWithdrawal)event.get("ongoingSuspiciousWithdrawal1"));
			accountUnderObservation.setAccount((Account)event.get("account"));
		}catch(Exception e){
    		System.out.println("AccountUnderObservation: " + e);
    	}
		
		return accountUnderObservation;
	}

	@Override
	public Object doActionAtCreateDeactivationEvent() {
		AccountUnderObservation accountUnderObservation = new AccountUnderObservation();
        
		try{
			accountUnderObservation.setOngoingSuspiciousWithdrawal1(this.getOngoingSuspiciousWithdrawal1());
			accountUnderObservation.setAccount(this.getAccount());
		}catch(Exception e){
    		System.out.println("AccountUnderObservation: " + e);
    	}
		
		return accountUnderObservation;
	}

}

