package .situation;

import com.espertech.esper.client.EventBean;

import .model.*;
import .situation.*;
import .*;

public class Fever extends Situation {
	
	private Patient patient;

	public void setPatient( Patient patient) {
		this.patient = patient;
	}
	
	public Patient getPatient() {
		return patient;
	}
	
	@Override
	public Fever(){
		setSitName("Fever");

		setEplA("select 	patient, patient.key as key1 	 from 	Patient as patient  where 	patient.temperature > 37");

		setEplA("select 	Fever, Fever.patient.key as key1 	 from 	Fever.std:unique(id) as Fever, Patient.std:unique(key) as patient1  where 	Fever.activated is true and ( (Fever.patient.key = patient1.key and not (patient1.temperature > 37)) )  ");
	}

	@Override
	public Situation createNewSit(EventBean event) {
		Fever fever = new Fever();
        
		try{
			fever.setPatient((Patient)event.get("patient"));
		}catch(Exception e){
    		System.out.println("Fever: " + e);
    	}
		
		return fever;
	}

	@Override
	public Object doActionAtCreateDeactivationEvent() {
		Fever fever = new Fever();
        
		try{
			fever.setPatient(this.getPatient());
		}catch(Exception e){
    		System.out.println("Fever: " + e);
    	}
		
		return fever;
	}

}

