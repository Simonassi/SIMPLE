package .situation;

import com.espertech.esper.client.EventBean;

import .model.*;
import .situation.*;
import .*;

public class SARI extends Situation {
	
	private ILI iLI1;
	private Requires_Hospitalization requires_Hospitalization1;
	private Patient patient1;
	private Patient patient2;

	public void setILI1( ILI iLI1) {
		this.iLI1 = iLI1;
	}
	
	public ILI getILI1() {
		return iLI1;
	}
	public void setRequires_Hospitalization1( Requires_Hospitalization requires_Hospitalization1) {
		this.requires_Hospitalization1 = requires_Hospitalization1;
	}
	
	public Requires_Hospitalization getRequires_Hospitalization1() {
		return requires_Hospitalization1;
	}
	public void setPatient1( Patient patient1) {
		this.patient1 = patient1;
	}
	
	public Patient getPatient1() {
		return patient1;
	}
	public void setPatient2( Patient patient2) {
		this.patient2 = patient2;
	}
	
	public Patient getPatient2() {
		return patient2;
	}
	
	@Override
	public SARI(){
		setSitName("SARI");

		setEplA("select 	iLI1, requires_Hospitalization1, iLI1.patient as patient1, requires_Hospitalization1.patient as patient2, iLI1.key as key1, requires_Hospitalization1.key as key2 	 from 	pattern[ every ( 		( 			 	every iLI1 = ILI(activated = true) 		 -> 	( 			 	every requires_Hospitalization1 = Requires_Hospitalization(activated = true) 				and not ILI(activated = false, id = iLI1.id) 				)where timer:within(10 days) 		) 		or ( 			 	every requires_Hospitalization1 = Requires_Hospitalization(activated = true) 		 -> 	( 			 	every iLI1 = ILI(activated = true) 				and not Requires_Hospitalization(activated = false, id = requires_Hospitalization1.id) 				)where timer:within(10 days) 		) 		) 	]  where 	iLI1.patient.name = requires_Hospitalization1.patient.name");

		setEplA("select 	SARI, SARI.iLI1.key as key1, SARI.requires_Hospitalization1.key as key2 	 from 	SARI.std:unique(id) as SARI, ILI.std:lastevent() as iLI1, Requires_Hospitalization.std:lastevent() as requires_Hospitalization1  where 	SARI.activated is true and ( (SARI.iLI1.id = iLI1.id and iLI1.activated is not true)  	or (SARI.requires_Hospitalization1.id = requires_Hospitalization1.id and requires_Hospitalization1.activated is not true)  or  (SARI.iLI1.patient.key = iLI1.patient.key and not (iLI1.patient.name = SARI.requires_Hospitalization1.patient.name))  	or (SARI.requires_Hospitalization1.patient.key = requires_Hospitalization1.patient.key and not (SARI.iLI1.patient.name = requires_Hospitalization1.patient.name)) )  ");
	}

	@Override
	public Situation createNewSit(EventBean event) {
		SARI sARI = new SARI();
        
		try{
			sARI.setILI1((ILI)event.get("iLI1"));
			sARI.setRequires_Hospitalization1((Requires_Hospitalization)event.get("requires_Hospitalization1"));
			sARI.setPatient1((Patient)event.get("patient1"));
			sARI.setPatient2((Patient)event.get("patient2"));
		}catch(Exception e){
    		System.out.println("SARI: " + e);
    	}
		
		return sARI;
	}

	@Override
	public Object doActionAtCreateDeactivationEvent() {
		SARI sARI = new SARI();
        
		try{
			sARI.setILI1(this.getILI1());
			sARI.setRequires_Hospitalization1(this.getRequires_Hospitalization1());
			sARI.setPatient1(this.getPatient1());
			sARI.setPatient2(this.getPatient2());
		}catch(Exception e){
    		System.out.println("SARI: " + e);
    	}
		
		return sARI;
	}

}

