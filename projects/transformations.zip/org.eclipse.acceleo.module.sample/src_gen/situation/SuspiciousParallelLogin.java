package .situation;

import com.espertech.esper.client.EventBean;

import .model.*;
import .situation.*;
import .*;

public class SuspiciousParallelLogin extends Situation {
	
	private LoggedIn loggedIn1;
	private LoggedIn loggedIn2;

	public void setLoggedIn1( LoggedIn loggedIn1) {
		this.loggedIn1 = loggedIn1;
	}
	
	public LoggedIn getLoggedIn1() {
		return loggedIn1;
	}
	public void setLoggedIn2( LoggedIn loggedIn2) {
		this.loggedIn2 = loggedIn2;
	}
	
	public LoggedIn getLoggedIn2() {
		return loggedIn2;
	}
	
	@Override
	public SuspiciousParallelLogin(){
		setSitName("SuspiciousParallelLogin");

		setEplA("select 	loggedIn1, loggedIn2, loggedIn1.key as key1, loggedIn2.key as key2 	 from 	pattern[ every ( 		( 			 	every loggedIn1 = LoggedIn(activated = true) 		 -> 	( 			 	every loggedIn2 = LoggedIn(activated = true) 				and not LoggedIn(activated = false, id = loggedIn1.id) 				) 		) 		or ( 			 	every loggedIn2 = LoggedIn(activated = true) 		 -> 	( 			 	every loggedIn1 = LoggedIn(activated = true) 				and not LoggedIn(activated = false, id = loggedIn2.id) 				) 		) 		) 	]  where 	loggedIn1.account = loggedIn2.account");

		setEplA("select 	SuspiciousParallelLogin, SuspiciousParallelLogin.loggedIn1.key as key1, SuspiciousParallelLogin.loggedIn2.key as key2 	 from 	SuspiciousParallelLogin.std:unique(id) as SuspiciousParallelLogin, LoggedIn.std:lastevent() as loggedIn1  where 	SuspiciousParallelLogin.activated is true and ( (SuspiciousParallelLogin.loggedIn1.id = loggedIn1.id and loggedIn1.activated is not true)  	or (SuspiciousParallelLogin.loggedIn2.id = loggedIn1.id and loggedIn1.activated is not true)  or  (SuspiciousParallelLogin.loggedIn1.id = loggedIn1.id and not (loggedIn1.account = SuspiciousParallelLogin.loggedIn2.account))  	or (SuspiciousParallelLogin.loggedIn2.id = loggedIn1.id and not (SuspiciousParallelLogin.loggedIn1.account = loggedIn1.account)) )  ");
	}

	@Override
	public Situation createNewSit(EventBean event) {
		SuspiciousParallelLogin suspiciousParallelLogin = new SuspiciousParallelLogin();
        
		try{
			suspiciousParallelLogin.setLoggedIn1((LoggedIn)event.get("loggedIn1"));
			suspiciousParallelLogin.setLoggedIn2((LoggedIn)event.get("loggedIn2"));
		}catch(Exception e){
    		System.out.println("SuspiciousParallelLogin: " + e);
    	}
		
		return suspiciousParallelLogin;
	}

	@Override
	public Object doActionAtCreateDeactivationEvent() {
		SuspiciousParallelLogin suspiciousParallelLogin = new SuspiciousParallelLogin();
        
		try{
			suspiciousParallelLogin.setLoggedIn1(this.getLoggedIn1());
			suspiciousParallelLogin.setLoggedIn2(this.getLoggedIn2());
		}catch(Exception e){
    		System.out.println("SuspiciousParallelLogin: " + e);
    	}
		
		return suspiciousParallelLogin;
	}

}

