package .situation;

import com.espertech.esper.client.EventBean;

import .model.*;
import .situation.*;
import .*;

public class SuspiciousFarawayLogin extends Situation {
	
	private LoggedIn loggedIn1;
	private LoggedIn loggedIn2;
	private Device device1;
	private Device device2;

	public void setLoggedIn1( LoggedIn loggedIn1) {
		this.loggedIn1 = loggedIn1;
	}
	
	public LoggedIn getLoggedIn1() {
		return loggedIn1;
	}
	public void setLoggedIn2( LoggedIn loggedIn2) {
		this.loggedIn2 = loggedIn2;
	}
	
	public LoggedIn getLoggedIn2() {
		return loggedIn2;
	}
	public void setDevice1( Device device1) {
		this.device1 = device1;
	}
	
	public Device getDevice1() {
		return device1;
	}
	public void setDevice2( Device device2) {
		this.device2 = device2;
	}
	
	public Device getDevice2() {
		return device2;
	}
	
	@Override
	public SuspiciousFarawayLogin(){
		setSitName("SuspiciousFarawayLogin");

		setEplA("select 	loggedIn1, loggedIn2, loggedIn1.device as device1, loggedIn2.device as device2, loggedIn1.key as key1, loggedIn2.key as key2 	 from 	pattern[ every ( 		( 			 	every loggedIn1 = LoggedIn(activated = false) 		 -> 	( 			 	every loggedIn2 = LoggedIn(activated = true) 				and not LoggedIn(activated = true, id = loggedIn1.id) 				)where timer:within(2 hours) 		) 		or ( 			 	every loggedIn2 = LoggedIn(activated = true) 		 -> 	( 			 	every loggedIn1 = LoggedIn(activated = false) 				and not LoggedIn(activated = false, id = loggedIn2.id) 				)where timer:within(2 hours) 		) 		) 	]  where 	loggedIn1.account = loggedIn2.account and not (near(loggedIn1.device.location, loggedIn2.device.location , '500km'))");

		setEplA("select 	SuspiciousFarawayLogin, SuspiciousFarawayLogin.loggedIn1.key as key1, SuspiciousFarawayLogin.loggedIn2.key as key2 	 from 	SuspiciousFarawayLogin.std:unique(id) as SuspiciousFarawayLogin, LoggedIn.std:lastevent() as loggedIn1  where 	SuspiciousFarawayLogin.activated is true and ( (SuspiciousFarawayLogin.loggedIn1.id = loggedIn1.id and loggedIn1.activated is not false)  	or (SuspiciousFarawayLogin.loggedIn2.id = loggedIn1.id and loggedIn1.activated is not true)  or  (SuspiciousFarawayLogin.loggedIn1.id = loggedIn1.id and not (loggedIn1.account = SuspiciousFarawayLogin.loggedIn2.account))  	or (SuspiciousFarawayLogin.loggedIn2.id = loggedIn1.id and not (SuspiciousFarawayLogin.loggedIn1.account = loggedIn1.account))  	or (SuspiciousFarawayLogin.loggedIn1.device.key = loggedIn1.device.key and not (not (near(loggedIn1.device.location, SuspiciousFarawayLogin.loggedIn2.device.location , '500km'))))  	or (SuspiciousFarawayLogin.loggedIn2.device.key = loggedIn1.device.key and not (not (near(SuspiciousFarawayLogin.loggedIn1.device.location, loggedIn1.device.location , '500km')))) )  ");
	}

	@Override
	public Situation createNewSit(EventBean event) {
		SuspiciousFarawayLogin suspiciousFarawayLogin = new SuspiciousFarawayLogin();
        
		try{
			suspiciousFarawayLogin.setLoggedIn1((LoggedIn)event.get("loggedIn1"));
			suspiciousFarawayLogin.setLoggedIn2((LoggedIn)event.get("loggedIn2"));
			suspiciousFarawayLogin.setDevice1((Device)event.get("device1"));
			suspiciousFarawayLogin.setDevice2((Device)event.get("device2"));
		}catch(Exception e){
    		System.out.println("SuspiciousFarawayLogin: " + e);
    	}
		
		return suspiciousFarawayLogin;
	}

	@Override
	public Object doActionAtCreateDeactivationEvent() {
		SuspiciousFarawayLogin suspiciousFarawayLogin = new SuspiciousFarawayLogin();
        
		try{
			suspiciousFarawayLogin.setLoggedIn1(this.getLoggedIn1());
			suspiciousFarawayLogin.setLoggedIn2(this.getLoggedIn2());
			suspiciousFarawayLogin.setDevice1(this.getDevice1());
			suspiciousFarawayLogin.setDevice2(this.getDevice2());
		}catch(Exception e){
    		System.out.println("SuspiciousFarawayLogin: " + e);
    	}
		
		return suspiciousFarawayLogin;
	}

}

