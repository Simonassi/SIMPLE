package .situation;

import com.espertech.esper.client.EventBean;

import .model.*;
import .situation.*;
import .*;

public class FunctionTest extends Situation {
	
	private Account account1;
	private OngoingWithdrawal ongoingWithdrawal1;
	private ATM aTM1;
	private Device device1;

	public void setAccount1( Account account1) {
		this.account1 = account1;
	}
	
	public Account getAccount1() {
		return account1;
	}
	public void setOngoingWithdrawal1( OngoingWithdrawal ongoingWithdrawal1) {
		this.ongoingWithdrawal1 = ongoingWithdrawal1;
	}
	
	public OngoingWithdrawal getOngoingWithdrawal1() {
		return ongoingWithdrawal1;
	}
	public void setATM1( ATM aTM1) {
		this.aTM1 = aTM1;
	}
	
	public ATM getATM1() {
		return aTM1;
	}
	public void setDevice1( Device device1) {
		this.device1 = device1;
	}
	
	public Device getDevice1() {
		return device1;
	}
	
	@Override
	public FunctionTest(){
		setSitName("FunctionTest");

		setEplA("select 	ongoingWithdrawal1.hasWithdrawal as account1, ongoingWithdrawal1, ongoingWithdrawal1.doWithdrawal as aTM1, device1, ongoingWithdrawal1.key as key1, device1.key as key2 	 from 	pattern[ every ( 		( 			 	every ongoingWithdrawal1 = OngoingWithdrawal(activated = true) 		 -> 	( 			 	every device1 = Device 				and not OngoingWithdrawal(activated = false, key = ongoingWithdrawal1.key) 				) 		) 		or ( 			 	every device1 = Device 		 -> 	( 			 	every ongoingWithdrawal1 = OngoingWithdrawal(activated = true) 				 				) 		) 		) 	]  where 	ongoingWithdrawal1.activated = true and ongoingWithdrawal1.doWithdrawal = device1 	and greaterThen(ongoingWithdrawal1.value, multiply(2, ongoingWithdrawal1.value), device1.location)");

		setEplA("select 	functionTest, functionTest.ongoingWithdrawal1.key as key1, functionTest.device1.key as key2 	 from 	functionTest.std:unique(id) as functionTest, OngoingWithdrawal.std:unique(key) as ongoingWithdrawal1, Device.std:unique(key) as device1  where 	functionTest.activated is true and ( (functionTest.ongoingWithdrawal1.key = ongoingWithdrawal1.key and ongoingWithdrawal1.activated is not true)  	or (functionTest.aTM1.key = aTM1.key and not (ongoingWithdrawal1.doWithdrawal = functionTest.device1))  	or (functionTest.device1.key = device1.key and not (functionTest.ongoingWithdrawal1.doWithdrawal = device1))  or (functionTest.ongoingWithdrawal1.key = ongoingWithdrawal1.key and not( greaterThen(ongoingWithdrawal1.value, multiply(2, ongoingWithdrawal1.value)  , functionTest.device1.location)) ) or (functionTest.ongoingWithdrawal1.key = ongoingWithdrawal1.key and not( greaterThen(ongoingWithdrawal1.value, multiply(2, ongoingWithdrawal1.value)  , functionTest.device1.location)) ) or (functionTest.device1.key = device1.key and not( greaterThen(functionTest.ongoingWithdrawal1.value, multiply(2, functionTest.ongoingWithdrawal1.value)  , device1.location)) ) ) ");
	}

	@Override
	public Situation createNewSit(EventBean event) {
		FunctionTest functionTest = new functionTest();
        
		try{
			functionTest.setAccount1((Account)event.get("account1"));
			functionTest.setOngoingWithdrawal1((OngoingWithdrawal)event.get("ongoingWithdrawal1"));
			functionTest.setATM1((ATM)event.get("aTM1"));
			functionTest.setDevice1((Device)event.get("device1"));
		}catch(Exception e){
    		System.out.println("FunctionTest: " + e);
    	}
		
		return functionTest;
	}

	@Override
	public Object doActionAtCreateDeactivationEvent() {
		FunctionTest functionTest = new functionTest();
        
		try{
			functionTest.setAccount1(this.getAccount1());
			functionTest.setOngoingWithdrawal1(this.getOngoingWithdrawal1());
			functionTest.setATM1(this.getATM1());
			functionTest.setDevice1(this.getDevice1());
		}catch(Exception e){
    		System.out.println("FunctionTest: " + e);
    	}
		
		return functionTest;
	}

}

