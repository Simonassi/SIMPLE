package .situation;

import com.espertech.esper.client.EventBean;

import .model.*;
import .situation.*;
import .*;

public class LoggedIn extends Situation {
	
	private Device device;
	private Access access1;
	private Account account;

	public void setDevice( Device device) {
		this.device = device;
	}
	
	public Device getDevice() {
		return device;
	}
	public void setAccess1( Access access1) {
		this.access1 = access1;
	}
	
	public Access getAccess1() {
		return access1;
	}
	public void setAccount( Account account) {
		this.account = account;
	}
	
	public Account getAccount() {
		return account;
	}
	
	@Override
	public LoggedIn(){
		setSitName("LoggedIn");

		setEplA("select 	access1.isAcessing as device, access1, access1.isAccessed as account, access1.key as key1 	 from 	Access as access1  where 	access1.activated = true");

		setEplA("select 	LoggedIn, LoggedIn.access1.key as key1 	 from 	LoggedIn.std:unique(id) as LoggedIn, Access.std:unique(key) as access1  where 	LoggedIn.activated is true and ( (LoggedIn.access1.key = access1.key and access1.activated is not true) )  ");
	}

	@Override
	public Situation createNewSit(EventBean event) {
		LoggedIn loggedIn = new LoggedIn();
        
		try{
			loggedIn.setDevice((Device)event.get("device"));
			loggedIn.setAccess1((Access)event.get("access1"));
			loggedIn.setAccount((Account)event.get("account"));
		}catch(Exception e){
    		System.out.println("LoggedIn: " + e);
    	}
		
		return loggedIn;
	}

	@Override
	public Object doActionAtCreateDeactivationEvent() {
		LoggedIn loggedIn = new LoggedIn();
        
		try{
			loggedIn.setDevice(this.getDevice());
			loggedIn.setAccess1(this.getAccess1());
			loggedIn.setAccount(this.getAccount());
		}catch(Exception e){
    		System.out.println("LoggedIn: " + e);
    	}
		
		return loggedIn;
	}

}

