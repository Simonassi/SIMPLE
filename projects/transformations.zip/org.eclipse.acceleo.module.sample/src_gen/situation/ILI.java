package .situation;

import com.espertech.esper.client.EventBean;

import .model.*;
import .situation.*;
import .*;

public class ILI extends Situation {
	
	private Fever fever1;
	private Cough cough1;
	private Patient patient1;
	private Patient patient;
	private Requires_Hospitalization requires_Hospitalization1;

	public void setFever1( Fever fever1) {
		this.fever1 = fever1;
	}
	
	public Fever getFever1() {
		return fever1;
	}
	public void setCough1( Cough cough1) {
		this.cough1 = cough1;
	}
	
	public Cough getCough1() {
		return cough1;
	}
	public void setPatient1( Patient patient1) {
		this.patient1 = patient1;
	}
	
	public Patient getPatient1() {
		return patient1;
	}
	public void setPatient( Patient patient) {
		this.patient = patient;
	}
	
	public Patient getPatient() {
		return patient;
	}
	public void setRequires_Hospitalization1( Requires_Hospitalization requires_Hospitalization1) {
		this.requires_Hospitalization1 = requires_Hospitalization1;
	}
	
	public Requires_Hospitalization getRequires_Hospitalization1() {
		return requires_Hospitalization1;
	}
	
	@Override
	public ILI(){
		setSitName("ILI");

		setEplA("select 	fever1, cough1, fever1.patient as patient1, cough1.patient as patient, requires_Hospitalization1, fever1.key as key1, cough1.key as key2, requires_Hospitalization1.key as key3 	 from 	pattern[ every ( 		( 			 	every fever1 = Fever(activated = true) 		 -> 	( 			 	every cough1 = Cough(activated = true) 				and not Fever(activated = false, id = fever1.id) 				) 		 -> 	( 			 	every requires_Hospitalization1 = Requires_Hospitalization(activated = true) 				and not Fever(activated = false, id = fever1.id) 				and not Cough(activated = false, id = cough1.id) 				) 		) 		or ( 			 	every fever1 = Fever(activated = true) 		 -> 	( 			 	every requires_Hospitalization1 = Requires_Hospitalization(activated = true) 				and not Fever(activated = false, id = fever1.id) 				) 		 -> 	( 			 	every cough1 = Cough(activated = true) 				and not Fever(activated = false, id = fever1.id) 				and not Requires_Hospitalization(activated = false, id = requires_Hospitalization1.id) 				)where timer:within(10 days) 		) 		or ( 			 	every cough1 = Cough(activated = true) 		 -> 	( 			 	every fever1 = Fever(activated = true) 				and not Cough(activated = false, id = cough1.id) 				) 		 -> 	( 			 	every requires_Hospitalization1 = Requires_Hospitalization(activated = true) 				and not Cough(activated = false, id = cough1.id) 				and not Fever(activated = false, id = fever1.id) 				) 		) 		or ( 			 	every cough1 = Cough(activated = true) 		 -> 	( 			 	every requires_Hospitalization1 = Requires_Hospitalization(activated = true) 				and not Cough(activated = false, id = cough1.id) 				) 		 -> 	( 			 	every fever1 = Fever(activated = true) 				and not Cough(activated = false, id = cough1.id) 				and not Requires_Hospitalization(activated = false, id = requires_Hospitalization1.id) 				)where timer:within(10 days) 		) 		or ( 			 	every requires_Hospitalization1 = Requires_Hospitalization(activated = true) 		 -> 	( 			 	every cough1 = Cough(activated = true) 				and not Requires_Hospitalization(activated = false, id = requires_Hospitalization1.id) 				) 		 -> 	( 			 	every fever1 = Fever(activated = true) 				and not Requires_Hospitalization(activated = false, id = requires_Hospitalization1.id) 				and not Cough(activated = false, id = cough1.id) 				)where timer:within(10 days) 		) 		or ( 			 	every requires_Hospitalization1 = Requires_Hospitalization(activated = true) 		 -> 	( 			 	every fever1 = Fever(activated = true) 				and not Requires_Hospitalization(activated = false, id = requires_Hospitalization1.id) 				) 		 -> 	( 			 	every cough1 = Cough(activated = true) 				and not Requires_Hospitalization(activated = false, id = requires_Hospitalization1.id) 				and not Fever(activated = false, id = fever1.id) 				)where timer:within(10 days) 		) 		) 	]  where 	fever1.patient.name = cough1.patient.name");

		setEplA("select 	ILI, ILI.fever1.key as key1, ILI.cough1.key as key2, ILI.requires_Hospitalization1.key as key3 	 from 	ILI.std:unique(id) as ILI, Fever.std:lastevent() as fever1, Cough.std:lastevent() as cough1, Requires_Hospitalization.std:lastevent() as requires_Hospitalization1  where 	ILI.activated is true and ( (ILI.fever1.id = fever1.id and fever1.activated is not true)  	or (ILI.cough1.id = cough1.id and cough1.activated is not true)  	or (ILI.requires_Hospitalization1.id = requires_Hospitalization1.id and requires_Hospitalization1.activated is not true)  or  (ILI.fever1.patient.key = fever1.patient.key and not (fever1.patient.name = ILI.cough1.patient.name))  	or (ILI.cough1.patient.key = cough1.patient.key and not (ILI.fever1.patient.name = cough1.patient.name)) )  ");
	}

	@Override
	public Situation createNewSit(EventBean event) {
		ILI iLI = new ILI();
        
		try{
			iLI.setFever1((Fever)event.get("fever1"));
			iLI.setCough1((Cough)event.get("cough1"));
			iLI.setPatient1((Patient)event.get("patient1"));
			iLI.setPatient((Patient)event.get("patient"));
			iLI.setRequires_Hospitalization1((Requires_Hospitalization)event.get("requires_Hospitalization1"));
		}catch(Exception e){
    		System.out.println("ILI: " + e);
    	}
		
		return iLI;
	}

	@Override
	public Object doActionAtCreateDeactivationEvent() {
		ILI iLI = new ILI();
        
		try{
			iLI.setFever1(this.getFever1());
			iLI.setCough1(this.getCough1());
			iLI.setPatient1(this.getPatient1());
			iLI.setPatient(this.getPatient());
			iLI.setRequires_Hospitalization1(this.getRequires_Hospitalization1());
		}catch(Exception e){
    		System.out.println("ILI: " + e);
    	}
		
		return iLI;
	}

}

