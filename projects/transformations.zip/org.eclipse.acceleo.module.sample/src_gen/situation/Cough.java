package .situation;

import com.espertech.esper.client.EventBean;

import .model.*;
import .situation.*;
import .*;

public class Cough extends Situation {
	
	private Patient patient;

	public void setPatient( Patient patient) {
		this.patient = patient;
	}
	
	public Patient getPatient() {
		return patient;
	}
	
	@Override
	public Cough(){
		setSitName("Cough");

		setEplA("select 	patient, patient.key as key1 	 from 	Patient as patient  where 	anyOf(patient.symptoms, 'cough' )");

		setEplA("select 	Cough, Cough.patient.key as key1 	 from 	Cough.std:unique(id) as Cough, Patient.std:unique(key) as patient1  where 	Cough.activated is true and ( (Cough.patient.key = patient1.key and not (anyOf(patient1.symptoms, 'cough' ))) )  ");
	}

	@Override
	public Situation createNewSit(EventBean event) {
		Cough cough = new Cough();
        
		try{
			cough.setPatient((Patient)event.get("patient"));
		}catch(Exception e){
    		System.out.println("Cough: " + e);
    	}
		
		return cough;
	}

	@Override
	public Object doActionAtCreateDeactivationEvent() {
		Cough cough = new Cough();
        
		try{
			cough.setPatient(this.getPatient());
		}catch(Exception e){
    		System.out.println("Cough: " + e);
    	}
		
		return cough;
	}

}

