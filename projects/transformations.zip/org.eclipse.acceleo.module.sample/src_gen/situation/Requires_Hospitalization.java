package .situation;

import com.espertech.esper.client.EventBean;

import .model.*;
import .situation.*;
import .*;

public class Requires_Hospitalization extends Situation {
	
	private Patient patient;

	public void setPatient( Patient patient) {
		this.patient = patient;
	}
	
	public Patient getPatient() {
		return patient;
	}
	
	@Override
	public Requires_Hospitalization(){
		setSitName("Requires Hospitalization");

		setEplA("select 	patient, patient.key as key1 	 from 	Patient as patient  where 	patient.requiresHospitalization = true");

		setEplA("select 	Requires Hospitalization, Requires Hospitalization.patient.key as key1 	 from 	Requires Hospitalization.std:unique(id) as Requires Hospitalization, Patient.std:unique(key) as patient1  where 	Requires Hospitalization.activated is true and ( (Requires Hospitalization.patient.key = patient1.key and not (patient1.requiresHospitalization = true)) )  ");
	}

	@Override
	public Situation createNewSit(EventBean event) {
		Requires Hospitalization requires Hospitalization = new Requires Hospitalization();
        
		try{
			requires Hospitalization.setPatient((Patient)event.get("patient"));
		}catch(Exception e){
    		System.out.println("Requires Hospitalization: " + e);
    	}
		
		return requires Hospitalization;
	}

	@Override
	public Object doActionAtCreateDeactivationEvent() {
		Requires Hospitalization requires Hospitalization = new Requires Hospitalization();
        
		try{
			requires Hospitalization.setPatient(this.getPatient());
		}catch(Exception e){
    		System.out.println("Requires Hospitalization: " + e);
    	}
		
		return requires Hospitalization;
	}

}

